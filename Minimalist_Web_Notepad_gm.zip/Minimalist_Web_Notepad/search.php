<?php
// Note: This file is included inside index.php, so it has access to $save_path and $base_url

$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
$results = [];

if ($search_query !== '') {
    // Get all files in the save directory
    $files = scandir($save_path);
    
    foreach ($files as $file) {
        // Skip current/parent directory pointers and .htaccess
        if ($file === '.' || $file === '..' || $file === '.htaccess') {
            continue;
        }

        $full_path = $save_path . '/' . $file;
        
        // Ensure it's a file
        if (!is_file($full_path)) {
            continue;
        }

        $match_found = false;

        // Step 1: Search Title (Filename)
        if (stripos($file, $search_query) !== false) {
            $match_found = true;
        } 
        // Step 2: Search Content (only if title didn't match to save resources)
        else {
            $content = file_get_contents($full_path);
            if (stripos($content, $search_query) !== false) {
                $match_found = true;
            }
        }

        if ($match_found) {
            $results[] = $file;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Notes</title>
    <link rel="shortcut icon" href="<?php print $base_url; ?>/favicon.ico">
    <link rel="stylesheet" href="<?php print $base_url; ?>/styles.css">
    <style>
        /* Minimalist overrides for the search page */
        body { font-family: sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
        .search-box { margin-bottom: 30px; }
        input[type="text"] { font-size: 16px; padding: 10px; width: 70%; border: 1px solid #ccc; }
        button { font-size: 16px; padding: 10px 20px; cursor: pointer; background: #eee; border: 1px solid #ccc; }
        ul { list-style: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { text-decoration: none; color: #333; font-size: 18px; border-bottom: 1px solid #eee; display: block; padding: 5px; }
        a:hover { background-color: #f9f9f9; border-bottom: 1px solid #ccc; }
        .nav { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="nav">
        <a href="<?php print $base_url; ?>/" style="display:inline; border:none; color:#999;">&larr; New Note</a>
    </div>

    <h1>Search Notes</h1>

    <div class="search-box">
        <form action="<?php print $base_url; ?>/search" method="get">
            <input type="text" name="q" placeholder="Search titles and content..." value="<?php echo htmlspecialchars($search_query); ?>" autofocus>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="results">
        <?php if ($search_query && empty($results)): ?>
            <p>No results found for "<strong><?php echo htmlspecialchars($search_query); ?></strong>".</p>
        <?php elseif (!empty($results)): ?>
            <ul>
                <?php foreach ($results as $note_name): ?>
                    <li>
                        <a href="<?php print $base_url . '/' . $note_name; ?>">
                            <?php echo htmlspecialchars($note_name); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>
